import { EditModeDirective } from './edit-mode.directive';

describe('EditModeDirective', () => {
  it('should create an instance', () => {
    const directive = new EditModeDirective();
    expect(directive).toBeTruthy();
  });
});
