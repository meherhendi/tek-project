import { ModuleWithProviders } from '@angular/core';
export declare class DateTimeEditorModule {
    static forRoot(): ModuleWithProviders;
}
