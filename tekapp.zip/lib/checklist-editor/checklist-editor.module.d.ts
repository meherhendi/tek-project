import { ModuleWithProviders } from '@angular/core';
export declare class CheckListEditorModule {
    static forRoot(): ModuleWithProviders;
}
