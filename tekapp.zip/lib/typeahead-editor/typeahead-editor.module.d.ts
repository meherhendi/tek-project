import { ModuleWithProviders } from '@angular/core';
export declare class TypeAheadEditorModule {
    static forRoot(): ModuleWithProviders;
}
