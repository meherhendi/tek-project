import { ModuleWithProviders } from '@angular/core';
export declare class TextAreaEditorModule {
    static forRoot(): ModuleWithProviders;
}
