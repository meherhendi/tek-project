import { ModuleWithProviders } from '@angular/core';
export declare class NumberEditorModule {
    static forRoot(): ModuleWithProviders;
}
