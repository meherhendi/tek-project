import { PipeTransform } from '@angular/core';
export declare class HighLightPipe implements PipeTransform {
    transform(text: string, search: string): string;
}
