import { PipeTransform } from '@angular/core';
export declare class typeaheadfilter implements PipeTransform {
    transform(items: any[], filter: string, displayValue: string): any;
}
