import { PipeTransform } from '@angular/core';
export declare class DisplayFieldNameFilter implements PipeTransform {
    transform(item: any, displayValue: string): any;
}
export declare class DisplayNameFilter implements PipeTransform {
    transform(item: any, displayValue: string): any;
}
