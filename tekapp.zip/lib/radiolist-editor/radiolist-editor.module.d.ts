import { ModuleWithProviders } from '@angular/core';
export declare class RadioListEditorModule {
    static forRoot(): ModuleWithProviders;
}
