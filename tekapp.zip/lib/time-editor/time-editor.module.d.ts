import { ModuleWithProviders } from '@angular/core';
export declare class TimeEditorModule {
    static forRoot(): ModuleWithProviders;
}
